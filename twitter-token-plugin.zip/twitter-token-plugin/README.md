# Twitter Token Giveaway Plugin

这是一个Twitter代币空投插件，允许用户通过与推文互动来领取代币。

## 功能特点

- Twitter互动验证（点赞、转发、评论）
- 内置钱包功能
- 自定义空投规则
- 防重复领取机制
- 实时代币余额显示

## 安装说明

1. 克隆仓库
```bash
git clone [repository-url]
```

2. 安装依赖
```bash
npm install
```

3. 启动开发服务器
```bash
npm start
```

## 配置说明

1. 在`.env`文件中配置以下环境变量：
- TWITTER_API_KEY
- TWITTER_API_SECRET
- WALLET_PRIVATE_KEY（可选）

## 使用方法

1. 连接Twitter账号
2. 设置空投规则
3. 存入代币
4. 开始空投活动

## 安全说明

- 请勿在代码中直接存储私钥
- 建议使用环境变量管理敏感信息
- 定期检查钱包余额和交易记录
